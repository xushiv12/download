#include"control.h"
int main(){
	loop loop;
    RUN run(make(set("13","OUTPUT"),loop.doit("13","HIGH")));
}
